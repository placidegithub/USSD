

const express = require('express')
const bodyParser = require('body-parser')

const app = express()
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

app.post('/ussd', (req, res) => {
    const { text } = req.body

    let response = ''

    if (text === '' || text.endsWith('*0')) {
        response = `CON Welcome to IT L7
        Airtime and Bundles Purchase
        1. Kinyarwanda
        2. English`
    } else if (text === '1') {
        response = `CON Hitamo nomero ya 4G cg andika nomero
        1. Shyiramo nomero ya mango
        0. Ahatangira`
    }else if (text === '1*1') {
        
        response = `CON Andika nomero ya 4G hano`
    }else if (text.startsWith('1*1') && text.match(/^1\*1\*077\d{7}$/)){
       
        response = `CON Hitamo Bundles
        1. Ukwezi 3GB - 2000 Frw
        2. Icyumweru 1GB - 700 Frw
        3. Umunsi 1GB promo - 300 Frw
        9. Gukomeza`
    }else if (text.startsWith('1*1') && text.endsWith('*1')) {
        response = `END Murakoze kugura bundle z'ukwezi 3GB kuri 2000 Frw.`
    }else if (text.startsWith('1*1') && text.endsWith('*2')) {
        response = `END Murakoze kugura bundle z'icyumweru 1GB kuri 700 Frw`
    }else if (text.startsWith('1*1') && text.endsWith('*3')) {
        response = `END Murakoze kugura bundle z'umunsi 1GB kuri 300 Frw`
    }else if (text.startsWith('1*1') && text.endsWith('*9')) {
        response = `CON 
        4. Ukwezi 5GB - 3000 Frw
        5. Ukwezi 7GB - 5000 Frw
        6. Ukwezi 8GB - 5900 Frw
        7. Ukwezi 10GB - 6000 Frw
        8. Ukwezi 11GB - 6900 Frw
        0. Ahatangira`
    }
    else if (text === '2') {
        response = `CON Choose 4G number or write a number
        1. Enter number
        0. Back`
    }else if (text === '2*1') {
       
        response = `CON Enter 4G Number`
    }
     else if (text.startsWith('2*1') && text.match(/^2\*1\*077\d{7}$/)) {
      
        response = `CON Choose Bundles
        1. Monthly 3GB - 2000 Frw
        2. Weekly 1GB - 700 Frw
        3. Vol Daily 1GB promo - 300Frw
        9. Next`
    }else if (text.startsWith('2*1') && text.endsWith('*1')) {
        response = `END You have successfully purchased Monthly 3GB bundle for 2000 Frw. Thank you!`
    }else if (text.startsWith('2*1') && text.endsWith('*2')) {
        response = `END You have successfully purchased Monthly 1GB bundle for 700 Frw. Thank you!`
    }else if (text.startsWith('2*1') && text.endsWith('*3')) {
        response = `END You have successfully purchased Vol Daily 1GB promo for 300 Frw. Thank you!`
    }else if (text.startsWith('2*1') && text.endsWith('*9')) {
        response = `CON 
        4. Monthly 5GB - 3000 Frw
        5. Monthly 7GB - 5000 Frw
        6. Monthly 8GB - 5900 Frw
        7. Monthly 10GB - 6000 Frw
        8. Monthly 11GB - 6900 Frw
        0. Back`
    }else {
        response = `END Invalid input. Please try again.`
    }

    res.set('Content-Type', 'text/plain')
    res.send(response)
});

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log(`USSD server is running on http://localhost:${PORT}`)
});